create definer = root@localhost view noteTable as
select `iNotesOfStudent`.`notes`.`id`        AS `id`,
       `iNotesOfStudent`.`types`.`type_name` AS `type_name`,
       `iNotesOfStudent`.`notes`.`title`     AS `note_name`,
       `iNotesOfStudent`.`notes`.`content`   AS `note_content`
from (`iNotesOfStudent`.`notes`
         join `iNotesOfStudent`.`types` on ((`iNotesOfStudent`.`types`.`id` = `iNotesOfStudent`.`notes`.`type_id`)));

